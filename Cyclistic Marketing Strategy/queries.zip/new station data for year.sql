select distinct  from_station_id as station_id, 
from_station_name  as station_name
from `citric-campaign-390403.stationdata.station-2018-maybe`
order by station_id
