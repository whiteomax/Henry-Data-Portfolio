create table `citric-campaign-390403.tripdata.2023_DT` (
  start_time timestamp,
  stop_time timestamp,
  usertype string

);

insert into `citric-campaign-390403.tripdata.2023_DT`(start_time,stop_time,usertype)
select started_at,ended_at,member_casual from `citric-campaign-390403.tripdata.trip-2023-01`;

insert into `citric-campaign-390403.tripdata.2023_DT`(start_time,stop_time,usertype)
select started_at,ended_at,member_casual from `citric-campaign-390403.tripdata.trip-2023-02`;

insert into `citric-campaign-390403.tripdata.2023_DT`(start_time,stop_time,usertype)
select started_at,ended_at,member_casual from `citric-campaign-390403.tripdata.trip-2023-03`;

insert into `citric-campaign-390403.tripdata.2023_DT`(start_time,stop_time,usertype)
select started_at,ended_at,member_casual from `citric-campaign-390403.tripdata.trip-2023-04`;

insert into `citric-campaign-390403.tripdata.2023_DT`(start_time,stop_time,usertype)
select started_at,ended_at,member_casual from `citric-campaign-390403.tripdata.trip-2023-05`;

insert into `citric-campaign-390403.tripdata.2023_DT`(start_time,stop_time,usertype)
select started_at,ended_at,member_casual from `citric-campaign-390403.tripdata.trip-2023-06`;
