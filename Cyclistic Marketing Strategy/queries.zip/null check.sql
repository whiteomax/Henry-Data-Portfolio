select count(*) from `citric-campaign-390403.tripdata.All-trip-2020`
where started_at is null
