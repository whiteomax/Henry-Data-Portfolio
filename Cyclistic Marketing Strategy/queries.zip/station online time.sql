select distinct from_station_id, from_station_name  from `citric-campaign-390403.tripdata.All-trip-2018`
except distinct select id, name from `citric-campaign-390403.stationdata.station-location-2017-Q4`
order by from_station_id

