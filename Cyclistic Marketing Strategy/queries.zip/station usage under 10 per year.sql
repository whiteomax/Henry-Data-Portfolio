SELECT 
SUM(case when (Sub_use + Cus_use) < 3650 then 1 else 0 end) as less_10,
SUM(case when (Sub_use + Cus_use) < 2190 then 1 else 0 end) as less_6,
SUM(case when (Sub_use + Cus_use) < 1095 then 1 else 0 end) as less_3,

FROM `citric-campaign-390403.Analytic.All-station-count-2013-19`

